const accounts = [];

module.exports = { accounts };
