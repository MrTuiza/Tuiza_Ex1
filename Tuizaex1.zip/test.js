const { calculateBMI, getCategory } = require("./bmi.js");
const { generateUniqueId } = require("./utils.js");
const validator = require("validator");
const fs = require("fs");

function addAccount(accountData) {
  const [firstName, lastName, email, age, bmiStatus] = accountData.slice(1);
  const id = generateUniqueId(firstName, lastName);

  if (
    accountData.length === 6 &&
    firstName &&
    lastName &&
    email &&
    age >= 18 &&
    validator.isEmail(email)
  ) {
    const account = { id, firstName, lastName, email, age, bmiStatus };
    const data = JSON.stringify(account) + '\n';
    fs.appendFileSync('accounts.json', data);
    return true;
  } else {
    return false;
  }
}

console.log("Welcome to the BMI Calculator!");
console.log("Please select an option:");
console.log("1. Calculate BMI");
console.log("2. Add new account");
console.log("3. Exit");

const readline = require("readline").createInterface({
  input: process.stdin,
  output: process.stdout,
});

readline.question("Enter option: ", (option) => {
  if (option === "1") {
    readline.question("Enter height (in cm): ", (height) => {
      readline.question("Enter weight (in kg): ", (weight) => {
        const bmi = calculateBMI(height, weight);
        const category = getCategory(bmi);
        console.log(`Your BMI is ${bmi.toFixed(2)}, which is ${category}.`);
        readline.close();
      });
    });
  } else if (option === "2") {
    readline.question("Enter first name: ", (firstName) => {
      readline.question("Enter last name: ", (lastName) => {
        readline.question("Enter email: ", (email) => {
          if (validator.isEmail(email)) {
            readline.question("Enter age: ", (age) => {
              if (age >= 18) {
                const bmiStatus = "getCategory(bmi)";
                const accountData = [
                  generateUniqueId(firstName, lastName),
                  firstName,
                  lastName,
                  email,
                  age,
                  bmiStatus,
                ];
                const result = addAccount(accountData);
                if (result) {
                  console.log(`Account successfully created. Unique ID: ${accountData[0]}`);
                } else {
                  console.log("Failed to create account. Please try again.");
                }
              } else {
                console.log("You must be at least 18 years old to create an account.");
              }
              readline.close();
            });
          } else {
            console.log("Invalid email address. Please try again.");
            readline.close();
          }
        });
      });
    });
  } else {
    readline.close();
  }
});
