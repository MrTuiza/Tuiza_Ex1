const fs = require("fs");
const validator = require("validator");

function generateUniqueId(firstName, lastName) {
  const random = Math.floor(Math.random() * 1000000);
  const timestamp = Date.now();
  const id = `${random}-${firstName}-${lastName}-${timestamp}`;
  return id;
}

function calculateBMI(height, weight) {
  const bmi = weight / ((height / 100) * (height / 100));
  return bmi;
}

function getCategory(bmi) {
  if (bmi < 18.5) {
    return "Underweight";
  } else if (bmi < 25) {
    return "Normal weight";
  } else if (bmi < 30) {
    return "Overweight";
  } else {
    return "Obese";
  }
}

function addAccount(accountData) {
  const [firstName, lastName, email, age, bmiStatus] = accountData.slice(1);
  const id = generateUniqueID(firstName, lastName);

  if (
    accountData.length === 6 &&
    firstName &&
    lastName &&
    email &&
    age >= 18 &&
    validator.isEmail(email)
  ) {
    const account = { id, firstName, lastName, email, age, bmiStatus };
    const data = JSON.stringify(account) + "\n";
    fs.appendFileSync("accounts.json", data);
    return true;
  } else {
    return false;
  }
}

function storeAccount(account) {
  const data = JSON.stringify(account) + "\n";
  fs.appendFileSync("accounts.json", data);
}

module.exports = {
  generateUniqueId,
  calculateBMI,
  getCategory,
  addAccount,
  storeAccount,
};

